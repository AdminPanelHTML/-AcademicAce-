var str=
'<div id="botBox">'+
'    <div id="spn" style="text-align:center">'+
'        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>'+
'        <!-- mobile-game -->'+
'        <ins class="adsbygoogle"'+
'             style="display:inline-block;width:320px;height:50px"'+
'             data-ad-client="ca-pub-4776032073028713"'+
'             data-ad-slot="6641027382"></ins>'+
'        <script>'+
'        (adsbygoogle = window.adsbygoogle || []).push({});'+
'        </script>'+
'    </div>'+
'    <div id="botBoxClose">x</div>'+
'</div>';
document.write(str);
